package ejemplo;

/**
 * Clase que representa un rectángulo.
 * 
 * @author Elena
 * @version 2.0
 */
public class Rectangle {

    private static final int FACTOR = 2;

    private int ancho;
    private int alto;
    
    /**
     * Constructor de la clase Rectangle.
     *
     * @param ancho ancho del rectángulo
     * @param alto alto del rectángulo
     */

    public Rectangle(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    /**
     * Comprueba si los valores del rectángulo son válidos.
     *
     * @return -1 si existen valores negativos, 0 si alguno es cero y 1 si son válidos
     */
    
    private int validateValues() {

        if (ancho < 0 || alto < 0) {
            return -1;
        }

        if (ancho == 0 || alto == 0) {
            return 0;
        }

        return 1;
    }
    
    /**
     * Calcula la superficie del rectángulo.
     *
     * @return superficie calculada
     */

    public int surface() {

        int validation = validateValues();

        if (validation != 1) {
            return validation;
        }

        return ancho * alto;
    }
    
    /**
     * Calcula el perímetro del rectángulo.
     *
     * @return perímetro calculado
     */

    public int perimeter() {

        int validation = validateValues();

        if (validation != 1) {
            return validation;
        }

        return FACTOR * ancho + FACTOR * alto;
    }
}
